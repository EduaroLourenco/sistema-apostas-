package br.edu.sistema.model;

public class Aposta {

    private int id;
    private Participante participante;
    private Partida partida;
    private int golsMandanteApostado;
    private int golsVisitanteApostado;
    private int pontosObtidos;

    public Aposta() {}

    public Aposta(Participante participante, Partida partida,
                  int golsMandante, int golsVisitante) {
        this.participante = participante;
        this.partida = partida;
        this.golsMandanteApostado = golsMandante;
        this.golsVisitanteApostado = golsVisitante;
    }

    public String getResultadoApostado() {
        if (golsMandanteApostado > golsVisitanteApostado) {
            return partida.getClubeMandante().getNome();
        }
        if (golsVisitanteApostado > golsMandanteApostado) {
            return partida.getClubeVisitante().getNome();
        }
        return "Empate";
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public Participante getParticipante() { return participante; }
    public void setParticipante(Participante participante) { this.participante = participante; }
    public Partida getPartida() { return partida; }
    public void setPartida(Partida partida) { this.partida = partida; }
    public int getGolsMandanteApostado() { return golsMandanteApostado; }
    public void setGolsMandanteApostado(int gols) { this.golsMandanteApostado = gols; }
    public int getGolsVisitanteApostado() { return golsVisitanteApostado; }
    public void setGolsVisitanteApostado(int gols) { this.golsVisitanteApostado = gols; }
    public int getPontosObtidos() { return pontosObtidos; }
    public void setPontosObtidos(int pontosObtidos) { this.pontosObtidos = pontosObtidos; }

    @Override
    public String toString() {
        return partida.toString() + " | Aposta: "
                + golsMandanteApostado + " x " + golsVisitanteApostado;
    }
}
