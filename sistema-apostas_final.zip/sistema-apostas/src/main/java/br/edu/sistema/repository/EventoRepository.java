package br.edu.sistema.repository;

import br.edu.sistema.db.ConexaoDB;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EventoRepository {

    private final Connection con;

    public EventoRepository() {
        this.con = ConexaoDB.getInstancia().getConexao();
    }

    public void registrar(String tipo, String descricao) {
        String sql = "INSERT INTO historico_eventos (tipo, descricao) VALUES (?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, tipo);
            ps.setString(2, descricao);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<String[]> buscarRecentes(int limite) {
        List<String[]> lista = new ArrayList<>();
        String sql = "SELECT TOP ? tipo, descricao, FORMATDATETIME(data_hora,'dd/MM/yyyy HH:mm:ss') dt FROM historico_eventos ORDER BY id DESC";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, limite);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new String[]{rs.getString("dt"), rs.getString("tipo"), rs.getString("descricao")});
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }
}
