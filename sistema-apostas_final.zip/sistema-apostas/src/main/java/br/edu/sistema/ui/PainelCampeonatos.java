package br.edu.sistema.ui;

import br.edu.sistema.model.Campeonato;
import br.edu.sistema.model.Clube;
import br.edu.sistema.service.SistemaApostas;
import br.edu.sistema.util.Tema;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PainelCampeonatos extends JPanel {

    private final SistemaApostas sistema = SistemaApostas.getInstancia();
    private JTextField txtNome, txtEdicao;
    private JComboBox<Campeonato> cbCampeonato;
    private JComboBox<Clube> cbClube;
    private DefaultTableModel tableModel;

    public PainelCampeonatos() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Tema.FUNDO_PAINEL);
        setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        construir();
        atualizar();
    }

    private void construir() {
        JPanel superior = new JPanel(new GridLayout(1, 2, 12, 0));
        superior.setOpaque(false);

        JPanel formCamp = Tema.painelForm("Novo Campeonato");
        formCamp.add(new JLabel("Nome:"), Tema.gbc(0, 0));
        txtNome = new JTextField(18);
        formCamp.add(txtNome, Tema.gbc(1, 0));
        formCamp.add(new JLabel("Edição:"), Tema.gbc(0, 1));
        txtEdicao = new JTextField(18);
        formCamp.add(txtEdicao, Tema.gbc(1, 1));
        JButton btnCadastrar = Tema.botaoPrimario("Cadastrar Campeonato");
        btnCadastrar.addActionListener(e -> cadastrar());
        formCamp.add(btnCadastrar, Tema.gbcSpan(0, 2, 2));
        superior.add(formCamp);

        JPanel formVinculo = Tema.painelForm("Adicionar Clube ao Campeonato");
        formVinculo.add(new JLabel("Campeonato:"), Tema.gbc(0, 0));
        cbCampeonato = new JComboBox<>();
        formVinculo.add(cbCampeonato, Tema.gbc(1, 0));
        formVinculo.add(new JLabel("Clube:"), Tema.gbc(0, 1));
        cbClube = new JComboBox<>();
        formVinculo.add(cbClube, Tema.gbc(1, 1));
        JButton btnAdd = Tema.botaoSecundario("Adicionar Clube");
        btnAdd.addActionListener(e -> adicionarClube());
        formVinculo.add(btnAdd, Tema.gbcSpan(0, 2, 2));
        superior.add(formVinculo);

        add(superior, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new String[]{"ID", "Nome", "Edição", "Clubes"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabela = Tema.estilizarTabela(new JTable(tableModel));
        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(Tema.bordaTitulada("Campeonatos Cadastrados"));
        add(scroll, BorderLayout.CENTER);
    }

    private void cadastrar() {
        String nome = txtNome.getText().trim();
        if (nome.isEmpty()) { JOptionPane.showMessageDialog(this, "Nome obrigatório.", "Atenção", JOptionPane.WARNING_MESSAGE); return; }
        JOptionPane.showMessageDialog(this, sistema.cadastrarCampeonato(nome, txtEdicao.getText().trim()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        txtNome.setText(""); txtEdicao.setText("");
        atualizar();
    }

    private void adicionarClube() {
        Campeonato camp = (Campeonato) cbCampeonato.getSelectedItem();
        Clube clube = (Clube) cbClube.getSelectedItem();
        JOptionPane.showMessageDialog(this, sistema.adicionarClubeAoCampeonato(camp, clube), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        atualizar();
    }

    private void atualizar() {
        tableModel.setRowCount(0);
        cbCampeonato.removeAllItems();
        cbClube.removeAllItems();

        List<Campeonato> camps = sistema.getCampeonatos();
        for (Campeonato c : camps) {
            cbCampeonato.addItem(c);
            List<Clube> clubes = sistema.getClubesDoCampeonato(c.getId());
            StringBuilder nomes = new StringBuilder();
            for (Clube cl : clubes) {
                if (nomes.length() > 0) nomes.append(", ");
                nomes.append(cl.getNome());
            }
            tableModel.addRow(new Object[]{
                c.getId(), c.getNome(), c.getEdicao(),
                clubes.size() + " — " + (nomes.length() > 0 ? nomes.toString() : "nenhum")
            });
        }
        for (Clube cl : sistema.getClubes()) cbClube.addItem(cl);
    }
}
