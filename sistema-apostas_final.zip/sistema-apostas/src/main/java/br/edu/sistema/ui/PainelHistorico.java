package br.edu.sistema.ui;

import br.edu.sistema.service.SistemaApostas;
import br.edu.sistema.util.Tema;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PainelHistorico extends JPanel {

    private final SistemaApostas sistema = SistemaApostas.getInstancia();
    private DefaultTableModel tableModel;

    public PainelHistorico() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Tema.FUNDO_PAINEL);
        setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        construir();
        atualizar();
    }

    private void construir() {
        JPanel topo = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
        topo.setOpaque(false);
        JLabel lblInfo = new JLabel("Registro automático de todas as ações realizadas no sistema.");
        lblInfo.setFont(new Font("SansSerif", Font.ITALIC, 12));
        lblInfo.setForeground(Color.GRAY);
        topo.add(lblInfo);
        JButton btnAtualizar = Tema.botaoSecundario("↻  Atualizar");
        btnAtualizar.setPreferredSize(new Dimension(130, 28));
        btnAtualizar.addActionListener(e -> atualizar());
        topo.add(btnAtualizar);
        add(topo, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new String[]{"Data/Hora", "Tipo", "Descrição"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable tabela = Tema.estilizarTabela(new JTable(tableModel));
        tabela.getColumnModel().getColumn(0).setPreferredWidth(140);
        tabela.getColumnModel().getColumn(1).setPreferredWidth(110);
        tabela.getColumnModel().getColumn(2).setPreferredWidth(500);

        tabela.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val, boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, val, sel, foc, row, col);
                String tipo = val != null ? val.toString() : "";
                setHorizontalAlignment(CENTER);
                if (!sel) {
                    setBackground(switch (tipo) {
                        case "RESULTADO" -> new Color(255, 230, 230);
                        case "APOSTA"    -> new Color(230, 245, 255);
                        case "CLUBE"     -> new Color(230, 255, 230);
                        case "CAMPEONATO"-> new Color(255, 250, 220);
                        case "GRUPO"     -> new Color(245, 235, 255);
                        case "PARTIDA"   -> new Color(255, 240, 220);
                        default          -> Color.WHITE;
                    });
                    setForeground(Color.DARK_GRAY);
                }
                return this;
            }
        });

        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(Tema.bordaTitulada("Histórico de Eventos  (50 mais recentes)"));
        add(scroll, BorderLayout.CENTER);
    }

    private void atualizar() {
        tableModel.setRowCount(0);
        List<String[]> eventos = sistema.getHistoricoRecente(50);
        for (String[] e : eventos) {
            tableModel.addRow(new Object[]{e[0], e[1], e[2]});
        }
    }
}
