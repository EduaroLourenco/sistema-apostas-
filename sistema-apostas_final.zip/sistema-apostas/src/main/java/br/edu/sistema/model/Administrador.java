package br.edu.sistema.model;

public class Administrador extends Pessoa {

    private String senha;

    public Administrador() { super(); }

    public Administrador(String nome, String email, String senha) {
        super(nome, email);
        this.senha = senha;
    }

    public boolean autenticar(String senhaInformada) {
        return this.senha != null && this.senha.equals(senhaInformada);
    }

    public boolean registrarResultadoPartida(Partida partida, int golsMandante, int golsVisitante) {
        if (partida == null) return false;
        partida.registrarResultado(golsMandante, golsVisitante);
        return true;
    }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    @Override
    public String getTipo() { return "Administrador"; }
}
