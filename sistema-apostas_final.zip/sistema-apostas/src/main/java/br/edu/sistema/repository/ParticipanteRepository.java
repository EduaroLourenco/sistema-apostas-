package br.edu.sistema.repository;

import br.edu.sistema.db.ConexaoDB;
import br.edu.sistema.model.Grupo;
import br.edu.sistema.model.Participante;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ParticipanteRepository implements Repository<Participante, Integer> {

    private final Connection con;

    public ParticipanteRepository() {
        this.con = ConexaoDB.getInstancia().getConexao();
    }

    @Override
    public Participante salvar(Participante p) {
        String sql = "INSERT INTO participantes (nome, email, total_pontos, grupo_id) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, p.getNome());
            ps.setString(2, p.getEmail());
            ps.setInt(3, p.getTotalPontos());
            if (p.getGrupo() != null) ps.setInt(4, p.getGrupo().getId());
            else ps.setNull(4, Types.INTEGER);
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) p.setId(keys.getInt(1));
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar participante: " + e.getMessage(), e);
        }
        return p;
    }

    @Override
    public Optional<Participante> buscarPorId(Integer id) {
        String sql = """
            SELECT p.*, g.id g_id, g.nome g_nome FROM participantes p
            LEFT JOIN grupos g ON p.grupo_id = g.id
            WHERE p.id = ?
            """;
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return Optional.of(mapear(rs));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return Optional.empty();
    }

    @Override
    public List<Participante> buscarTodos() {
        List<Participante> lista = new ArrayList<>();
        String sql = """
            SELECT p.*, g.id g_id, g.nome g_nome FROM participantes p
            LEFT JOIN grupos g ON p.grupo_id = g.id
            ORDER BY p.total_pontos DESC, p.nome
            """;
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    public List<Participante> buscarPorGrupo(int grupoId) {
        List<Participante> lista = new ArrayList<>();
        String sql = """
            SELECT p.*, g.id g_id, g.nome g_nome FROM participantes p
            LEFT JOIN grupos g ON p.grupo_id = g.id
            WHERE p.grupo_id = ? ORDER BY p.total_pontos DESC
            """;
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, grupoId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    @Override
    public boolean deletar(Integer id) {
        try (PreparedStatement ps = con.prepareStatement("DELETE FROM participantes WHERE id = ?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Participante atualizar(Participante p) {
        String sql = "UPDATE participantes SET nome=?, email=?, total_pontos=?, grupo_id=? WHERE id=?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNome());
            ps.setString(2, p.getEmail());
            ps.setInt(3, p.getTotalPontos());
            if (p.getGrupo() != null) ps.setInt(4, p.getGrupo().getId());
            else ps.setNull(4, Types.INTEGER);
            ps.setInt(5, p.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return p;
    }

    public static Participante mapear(ResultSet rs) throws SQLException {
        Participante p = new Participante();
        p.setId(rs.getInt("id"));
        p.setNome(rs.getString("nome"));
        p.setEmail(rs.getString("email"));
        p.setTotalPontos(rs.getInt("total_pontos"));

        int grupoId = rs.getInt("g_id");
        if (!rs.wasNull()) {
            Grupo g = new Grupo();
            g.setId(grupoId);
            g.setNome(rs.getString("g_nome"));
            p.setGrupo(g);
        }
        return p;
    }
}
