package br.edu.sistema.interfaces;

public interface Cadastravel {
    boolean cadastrar();
    String getInfo();
}
