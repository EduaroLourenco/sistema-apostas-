package br.edu.sistema.ui;

import br.edu.sistema.model.Campeonato;
import br.edu.sistema.model.Clube;
import br.edu.sistema.model.Partida;
import br.edu.sistema.service.SistemaApostas;
import br.edu.sistema.util.Tema;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class PainelPartidas extends JPanel {

    private final SistemaApostas sistema = SistemaApostas.getInstancia();
    private JComboBox<Campeonato> cbCampeonato;
    private JComboBox<Clube> cbMandante, cbVisitante;
    private JTextField txtDataHora;
    private DefaultTableModel tableModel;

    public PainelPartidas() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Tema.FUNDO_PAINEL);
        setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        construir();
        atualizar();
    }

    private void construir() {
        JPanel form = Tema.painelForm("Cadastrar Partida");

        form.add(new JLabel("Campeonato:"), Tema.gbc(0, 0));
        cbCampeonato = new JComboBox<>();
        cbCampeonato.addActionListener(e -> carregarClubesDoCampeonato());
        form.add(cbCampeonato, Tema.gbc(1, 0));

        form.add(new JLabel("Clube Mandante:"), Tema.gbc(0, 1));
        cbMandante = new JComboBox<>();
        form.add(cbMandante, Tema.gbc(1, 1));

        form.add(new JLabel("Clube Visitante:"), Tema.gbc(0, 2));
        cbVisitante = new JComboBox<>();
        form.add(cbVisitante, Tema.gbc(1, 2));

        form.add(new JLabel("Data/Hora (dd/MM/yyyy HH:mm):"), Tema.gbc(0, 3));
        txtDataHora = new JTextField("01/07/2026 16:00", 18);
        form.add(txtDataHora, Tema.gbc(1, 3));

        JButton btn = Tema.botaoPrimario("Cadastrar Partida");
        btn.addActionListener(e -> cadastrar());
        form.add(btn, Tema.gbcSpan(0, 4, 2));

        add(form, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(
                new String[]{"ID", "Campeonato", "Mandante", "Visitante", "Data/Hora", "Situação"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabela = Tema.estilizarTabela(new JTable(tableModel));
        tabela.getColumnModel().getColumn(0).setPreferredWidth(40);
        tabela.getColumnModel().getColumn(5).setPreferredWidth(160);

        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(Tema.bordaTitulada("Partidas Cadastradas"));
        add(scroll, BorderLayout.CENTER);

        carregarCampeonatos();
    }

    private void carregarCampeonatos() {
        cbCampeonato.removeAllItems();
        for (Campeonato c : sistema.getCampeonatos()) cbCampeonato.addItem(c);
        carregarClubesDoCampeonato();
    }

    private void carregarClubesDoCampeonato() {
        cbMandante.removeAllItems();
        cbVisitante.removeAllItems();
        Campeonato camp = (Campeonato) cbCampeonato.getSelectedItem();
        if (camp == null) return;
        List<Clube> clubes = sistema.getClubesDoCampeonato(camp.getId());
        for (Clube c : clubes) {
            cbMandante.addItem(c);
            cbVisitante.addItem(c);
        }
    }

    private void cadastrar() {
        Campeonato camp = (Campeonato) cbCampeonato.getSelectedItem();
        Clube mandante = (Clube) cbMandante.getSelectedItem();
        Clube visitante = (Clube) cbVisitante.getSelectedItem();
        String dataStr = txtDataHora.getText().trim();

        if (camp == null || mandante == null || visitante == null || dataStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        LocalDateTime dataHora;
        try {
            dataHora = LocalDateTime.parse(dataStr, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Formato inválido. Use: dd/MM/yyyy HH:mm", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(this, sistema.cadastrarPartida(camp, mandante, visitante, dataHora),
                "Resultado", JOptionPane.INFORMATION_MESSAGE);
        atualizar();
    }

    private void atualizar() {
        tableModel.setRowCount(0);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        for (Partida p : sistema.getTodasPartidas()) {
            String situacao = p.isFinalizada()
                    ? "Finalizada: " + p.getGolsMandante() + " x " + p.getGolsVisitante()
                    : "Aguardando";
            tableModel.addRow(new Object[]{
                p.getId(),
                p.getCampeonato().getNome(),
                p.getClubeMandante().getNome(),
                p.getClubeVisitante().getNome(),
                p.getDataHora().format(fmt),
                situacao
            });
        }
        carregarCampeonatos();
    }
}
