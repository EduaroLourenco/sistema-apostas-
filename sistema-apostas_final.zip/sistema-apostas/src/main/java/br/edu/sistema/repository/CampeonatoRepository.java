package br.edu.sistema.repository;

import br.edu.sistema.db.ConexaoDB;
import br.edu.sistema.model.Campeonato;
import br.edu.sistema.model.Clube;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CampeonatoRepository implements Repository<Campeonato, Integer> {

    private final Connection con;
    private final ClubeRepository clubeRepo;

    public CampeonatoRepository() {
        this.con = ConexaoDB.getInstancia().getConexao();
        this.clubeRepo = new ClubeRepository();
    }

    @Override
    public Campeonato salvar(Campeonato camp) {
        String sql = "INSERT INTO campeonatos (nome, edicao) VALUES (?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, camp.getNome());
            ps.setString(2, camp.getEdicao());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) camp.setId(keys.getInt(1));
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar campeonato: " + e.getMessage(), e);
        }
        return camp;
    }

    @Override
    public Optional<Campeonato> buscarPorId(Integer id) {
        String sql = "SELECT * FROM campeonatos WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Campeonato camp = mapear(rs);
                carregarClubes(camp);
                return Optional.of(camp);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return Optional.empty();
    }

    @Override
    public List<Campeonato> buscarTodos() {
        List<Campeonato> lista = new ArrayList<>();
        String sql = "SELECT * FROM campeonatos ORDER BY nome";
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Campeonato camp = mapear(rs);
                carregarClubes(camp);
                lista.add(camp);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    @Override
    public boolean deletar(Integer id) {
        try (PreparedStatement ps = con.prepareStatement("DELETE FROM campeonatos WHERE id = ?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Campeonato atualizar(Campeonato camp) {
        String sql = "UPDATE campeonatos SET nome = ?, edicao = ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, camp.getNome());
            ps.setString(2, camp.getEdicao());
            ps.setInt(3, camp.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return camp;
    }

    public void vincularClube(int campeonatoId, int clubeId) {
        String sql = "MERGE INTO campeonato_clubes (campeonato_id, clube_id) VALUES (?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, campeonatoId);
            ps.setInt(2, clubeId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Clube> buscarClubesDoCampeonato(int campeonatoId) {
        List<Clube> clubes = new ArrayList<>();
        String sql = """
            SELECT c.* FROM clubes c
            JOIN campeonato_clubes cc ON c.id = cc.clube_id
            WHERE cc.campeonato_id = ? ORDER BY c.nome
            """;
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, campeonatoId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) clubes.add(ClubeRepository.mapear(rs));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return clubes;
    }

    private void carregarClubes(Campeonato camp) {
        List<Clube> clubes = buscarClubesDoCampeonato(camp.getId());
        for (Clube c : clubes) camp.adicionarClube(c);
    }

    public static Campeonato mapear(ResultSet rs) throws SQLException {
        Campeonato c = new Campeonato();
        c.setId(rs.getInt("id"));
        c.setNome(rs.getString("nome"));
        c.setEdicao(rs.getString("edicao"));
        return c;
    }
}
