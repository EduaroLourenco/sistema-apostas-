package br.edu.sistema.model;

import br.edu.sistema.interfaces.Cadastravel;

public abstract class EntidadeBase implements Cadastravel {

    private int id;
    private String nome;

    public EntidadeBase() {}

    public EntidadeBase(String nome) {
        this.nome = nome;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    @Override
    public boolean cadastrar() {
        return nome != null && !nome.trim().isEmpty();
    }

    @Override
    public String getInfo() {
        return "ID: " + id + " | Nome: " + nome;
    }

    public abstract String getTipoEntidade();

    @Override
    public String toString() { return nome; }
}
