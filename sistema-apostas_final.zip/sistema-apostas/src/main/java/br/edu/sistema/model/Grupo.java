package br.edu.sistema.model;

import br.edu.sistema.interfaces.Cadastravel;
import br.edu.sistema.interfaces.Visualizavel;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Grupo implements Cadastravel, Visualizavel {

    public static final int MAX_PARTICIPANTES = 10;

    private int id;
    private String nome;
    private List<Participante> participantes = new ArrayList<>();

    public Grupo() {}

    public Grupo(String nome) {
        this.nome = nome;
    }

    public boolean adicionarParticipante(Participante participante) {
        if (participantes.size() >= MAX_PARTICIPANTES) return false;
        if (participantes.stream().anyMatch(p -> p.getId() == participante.getId())) return false;
        participante.setGrupo(this);
        return participantes.add(participante);
    }

    @Override
    public boolean cadastrar() {
        return nome != null && !nome.trim().isEmpty();
    }

    @Override
    public String getInfo() {
        return "ID: " + id + " | Grupo: " + nome
                + " | Participantes: " + participantes.size() + "/" + MAX_PARTICIPANTES;
    }

    @Override
    public String exibirClassificacao() {
        StringBuilder sb = new StringBuilder();
        sb.append("═══════════════════════════════════\n");
        sb.append("    CLASSIFICAÇÃO — ").append(nome).append("\n");
        sb.append("═══════════════════════════════════\n");

        List<Participante> ordenados = new ArrayList<>(participantes);
        ordenados.sort(Comparator.comparingInt(Participante::getTotalPontos).reversed());

        int pos = 1;
        for (Participante p : ordenados) {
            String medalha = pos == 1 ? "🥇" : pos == 2 ? "🥈" : pos == 3 ? "🥉" : pos + "º";
            sb.append(medalha).append("  ").append(p.getNome())
              .append("  —  ").append(p.getTotalPontos()).append(" pts\n");
            pos++;
        }

        if (participantes.isEmpty()) {
            sb.append("Nenhum participante no grupo.\n");
        }

        return sb.toString();
    }

    @Override
    public String exibirDetalhes() {
        StringBuilder sb = new StringBuilder();
        sb.append("Grupo: ").append(nome).append("\n");
        sb.append("Participantes:\n");
        for (Participante p : participantes) {
            sb.append("  • ").append(p.getInfo()).append("\n");
        }
        return sb.toString();
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public List<Participante> getParticipantes() { return participantes; }

    @Override
    public String toString() { return nome; }
}
