package br.edu.sistema.ui;

import br.edu.sistema.model.Grupo;
import br.edu.sistema.model.Partida;
import br.edu.sistema.model.Participante;
import br.edu.sistema.service.SistemaApostas;
import br.edu.sistema.util.Tema;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PainelResultados extends JPanel {

    private final SistemaApostas sistema = SistemaApostas.getInstancia();
    private JComboBox<Partida> cbPartida;
    private JSpinner spMandante, spVisitante;
    private JPasswordField txtSenha;
    private JComboBox<Grupo> cbGrupo;
    private JTextArea areaClassificacao;
    private DefaultTableModel tableModel;

    public PainelResultados() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Tema.FUNDO_PAINEL);
        setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        construir();
        atualizar();
    }

    private void construir() {
        JPanel superior = new JPanel(new GridLayout(1, 2, 12, 0));
        superior.setOpaque(false);

        JPanel formAdmin = Tema.painelForm("Registrar Resultado  (Administrador)");

        formAdmin.add(new JLabel("Partida:"), Tema.gbc(0, 0));
        cbPartida = new JComboBox<>();
        formAdmin.add(cbPartida, Tema.gbc(1, 0));

        formAdmin.add(new JLabel("Gols Mandante:"), Tema.gbc(0, 1));
        spMandante = new JSpinner(new SpinnerNumberModel(0, 0, 20, 1));
        formAdmin.add(spMandante, Tema.gbc(1, 1));

        formAdmin.add(new JLabel("Gols Visitante:"), Tema.gbc(0, 2));
        spVisitante = new JSpinner(new SpinnerNumberModel(0, 0, 20, 1));
        formAdmin.add(spVisitante, Tema.gbc(1, 2));

        formAdmin.add(new JLabel("Senha Admin:"), Tema.gbc(0, 3));
        txtSenha = new JPasswordField(14);
        formAdmin.add(txtSenha, Tema.gbc(1, 3));

        JButton btnConfirmar = Tema.botaoDanger("Confirmar Resultado");
        btnConfirmar.addActionListener(e -> registrarResultado());
        formAdmin.add(btnConfirmar, Tema.gbcSpan(0, 4, 2));

        superior.add(formAdmin);

        JPanel formClass = Tema.painelForm("Classificação do Grupo");
        formClass.setLayout(new BorderLayout(6, 6));

        JPanel topClass = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        topClass.setOpaque(false);
        topClass.add(new JLabel("Grupo:"));
        cbGrupo = new JComboBox<>();
        topClass.add(cbGrupo);
        JButton btnVer = Tema.botaoSecundario("Ver Classificação");
        btnVer.setPreferredSize(new Dimension(150, 28));
        btnVer.addActionListener(e -> exibirClassificacao());
        topClass.add(btnVer);
        formClass.add(topClass, BorderLayout.NORTH);

        areaClassificacao = new JTextArea(8, 28);
        areaClassificacao.setEditable(false);
        areaClassificacao.setFont(Tema.MONO_FONTE);
        areaClassificacao.setBackground(new Color(245, 250, 245));
        areaClassificacao.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
        formClass.add(new JScrollPane(areaClassificacao), BorderLayout.CENTER);

        superior.add(formClass);
        add(superior, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new String[]{"Partida", "Resultado", "Situação"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabela = Tema.estilizarTabela(new JTable(tableModel));
        tabela.getColumnModel().getColumn(2).setPreferredWidth(100);

        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(Tema.bordaTitulada("Todas as Partidas"));
        add(scroll, BorderLayout.CENTER);
    }

    private void registrarResultado() {
        Partida partida = (Partida) cbPartida.getSelectedItem();
        if (partida == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma partida.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int gM = (Integer) spMandante.getValue();
        int gV = (Integer) spVisitante.getValue();
        String senha = new String(txtSenha.getPassword());

        String msg = sistema.registrarResultado(partida, gM, gV, senha);
        int tipo = msg.contains("negado") || msg.contains("incorreta")
                ? JOptionPane.ERROR_MESSAGE : JOptionPane.INFORMATION_MESSAGE;
        JOptionPane.showMessageDialog(this, msg, "Resultado", tipo);
        txtSenha.setText("");
        atualizar();
    }

    private void exibirClassificacao() {
        Grupo grupo = (Grupo) cbGrupo.getSelectedItem();
        if (grupo == null) { areaClassificacao.setText("Nenhum grupo selecionado."); return; }

        List<Participante> membros = sistema.getParticipantesPorGrupo(grupo.getId());
        grupo.getParticipantes().clear();
        membros.forEach(grupo::adicionarParticipante);
        areaClassificacao.setText(grupo.exibirClassificacao());
    }

    private void atualizar() {
        cbPartida.removeAllItems();
        for (Partida p : sistema.getTodasPartidas()) {
            if (!p.isFinalizada()) cbPartida.addItem(p);
        }

        cbGrupo.removeAllItems();
        for (Grupo g : sistema.getGrupos()) cbGrupo.addItem(g);

        tableModel.setRowCount(0);
        for (Partida p : sistema.getTodasPartidas()) {
            String resultado = p.isFinalizada()
                    ? p.getGolsMandante() + " x " + p.getGolsVisitante() + "  (" + p.getResultado() + ")"
                    : "—";
            tableModel.addRow(new Object[]{
                p.toString(), resultado,
                p.isFinalizada() ? "Finalizada" : "Aguardando"
            });
        }
    }
}
