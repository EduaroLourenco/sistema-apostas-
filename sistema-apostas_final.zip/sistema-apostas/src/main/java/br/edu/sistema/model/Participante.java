package br.edu.sistema.model;

import br.edu.sistema.interfaces.Cadastravel;
import br.edu.sistema.interfaces.Pontuavel;

import java.util.ArrayList;
import java.util.List;

public class Participante extends Pessoa implements Pontuavel, Cadastravel {

    private int id;
    private int totalPontos;
    private List<Aposta> apostas = new ArrayList<>();
    private Grupo grupo;

    public Participante() { super(); }

    public Participante(String nome, String email) {
        super(nome, email);
        this.totalPontos = 0;
    }

    public boolean registrarAposta(Aposta aposta) {
        if (!aposta.getPartida().isApostaPermitida()) return false;
        boolean jaApostou = apostas.stream()
                .anyMatch(a -> a.getPartida().getId() == aposta.getPartida().getId());
        if (jaApostou) return false;
        return apostas.add(aposta);
    }

    @Override
    public int calcularPontos(Aposta aposta, Partida partida) {
        if (!partida.isFinalizada()) return 0;

        boolean placarExato = aposta.getGolsMandanteApostado() == partida.getGolsMandante()
                && aposta.getGolsVisitanteApostado() == partida.getGolsVisitante();
        if (placarExato) return 10;

        boolean resultadoCerto = aposta.getResultadoApostado().equals(partida.getResultado());
        if (resultadoCerto) return 5;

        return 0;
    }

    @Override
    public int getTotalPontos() { return totalPontos; }

    @Override
    public void adicionarPontos(int pontos) { this.totalPontos += pontos; }

    public void setTotalPontos(int totalPontos) { this.totalPontos = totalPontos; }

    @Override
    public boolean cadastrar() {
        return getNome() != null && !getNome().trim().isEmpty()
                && getEmail() != null && !getEmail().trim().isEmpty();
    }

    @Override
    public String getInfo() {
        return "ID: " + id + " | " + getNome() + " | Pontos: " + totalPontos;
    }

    @Override
    public String getTipo() { return "Participante"; }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public List<Aposta> getApostas() { return apostas; }
    public Grupo getGrupo() { return grupo; }
    public void setGrupo(Grupo grupo) { this.grupo = grupo; }
}
