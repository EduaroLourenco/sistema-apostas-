package br.edu.sistema.interfaces;

import br.edu.sistema.model.Aposta;
import br.edu.sistema.model.Partida;

public interface Pontuavel {
    int calcularPontos(Aposta aposta, Partida partida);
    int getTotalPontos();
    void adicionarPontos(int pontos);
}
