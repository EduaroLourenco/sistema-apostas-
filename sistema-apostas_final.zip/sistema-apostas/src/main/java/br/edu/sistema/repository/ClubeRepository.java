package br.edu.sistema.repository;

import br.edu.sistema.db.ConexaoDB;
import br.edu.sistema.model.Clube;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ClubeRepository implements Repository<Clube, Integer> {

    private final Connection con;

    public ClubeRepository() {
        this.con = ConexaoDB.getInstancia().getConexao();
    }

    @Override
    public Clube salvar(Clube clube) {
        String sql = "INSERT INTO clubes (nome, cidade, estadio) VALUES (?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, clube.getNome());
            ps.setString(2, clube.getCidade());
            ps.setString(3, clube.getEstadio());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) clube.setId(keys.getInt(1));
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar clube: " + e.getMessage(), e);
        }
        return clube;
    }

    @Override
    public Optional<Clube> buscarPorId(Integer id) {
        String sql = "SELECT * FROM clubes WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return Optional.of(mapear(rs));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return Optional.empty();
    }

    @Override
    public List<Clube> buscarTodos() {
        List<Clube> lista = new ArrayList<>();
        String sql = "SELECT * FROM clubes ORDER BY nome";
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    @Override
    public boolean deletar(Integer id) {
        try (PreparedStatement ps = con.prepareStatement("DELETE FROM clubes WHERE id = ?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Clube atualizar(Clube clube) {
        String sql = "UPDATE clubes SET nome = ?, cidade = ?, estadio = ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, clube.getNome());
            ps.setString(2, clube.getCidade());
            ps.setString(3, clube.getEstadio());
            ps.setInt(4, clube.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return clube;
    }

    public static Clube mapear(ResultSet rs) throws SQLException {
        Clube c = new Clube();
        c.setId(rs.getInt("id"));
        c.setNome(rs.getString("nome"));
        c.setCidade(rs.getString("cidade"));
        c.setEstadio(rs.getString("estadio"));
        return c;
    }
}
