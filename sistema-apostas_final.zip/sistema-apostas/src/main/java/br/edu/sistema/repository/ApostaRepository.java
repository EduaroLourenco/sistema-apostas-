package br.edu.sistema.repository;

import br.edu.sistema.db.ConexaoDB;
import br.edu.sistema.model.Aposta;
import br.edu.sistema.model.Participante;
import br.edu.sistema.model.Partida;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ApostaRepository implements Repository<Aposta, Integer> {

    private final Connection con;

    public ApostaRepository() {
        this.con = ConexaoDB.getInstancia().getConexao();
    }

    @Override
    public Aposta salvar(Aposta aposta) {
        String sql = """
            INSERT INTO apostas (participante_id, partida_id, gols_mandante_apostado,
                gols_visitante_apostado, pontos_obtidos)
            VALUES (?, ?, ?, ?, ?)
            """;
        try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, aposta.getParticipante().getId());
            ps.setInt(2, aposta.getPartida().getId());
            ps.setInt(3, aposta.getGolsMandanteApostado());
            ps.setInt(4, aposta.getGolsVisitanteApostado());
            ps.setInt(5, aposta.getPontosObtidos());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) aposta.setId(keys.getInt(1));
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar aposta: " + e.getMessage(), e);
        }
        return aposta;
    }

    public void atualizarPontos(int apostaId, int pontos) {
        String sql = "UPDATE apostas SET pontos_obtidos = ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, pontos);
            ps.setInt(2, apostaId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Aposta> buscarPorPartida(int partidaId, PartidaRepository partidaRepo, ParticipanteRepository partRepo) {
        List<Aposta> lista = new ArrayList<>();
        String sql = "SELECT * FROM apostas WHERE partida_id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, partidaId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Aposta a = new Aposta();
                a.setId(rs.getInt("id"));
                a.setGolsMandanteApostado(rs.getInt("gols_mandante_apostado"));
                a.setGolsVisitanteApostado(rs.getInt("gols_visitante_apostado"));
                a.setPontosObtidos(rs.getInt("pontos_obtidos"));
                partidaRepo.buscarPorId(rs.getInt("partida_id")).ifPresent(a::setPartida);
                partRepo.buscarPorId(rs.getInt("participante_id")).ifPresent(a::setParticipante);
                lista.add(a);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    public List<Aposta> buscarPorParticipante(int participanteId, PartidaRepository partidaRepo, ParticipanteRepository partRepo) {
        List<Aposta> lista = new ArrayList<>();
        String sql = "SELECT * FROM apostas WHERE participante_id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, participanteId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Aposta a = new Aposta();
                a.setId(rs.getInt("id"));
                a.setGolsMandanteApostado(rs.getInt("gols_mandante_apostado"));
                a.setGolsVisitanteApostado(rs.getInt("gols_visitante_apostado"));
                a.setPontosObtidos(rs.getInt("pontos_obtidos"));
                partidaRepo.buscarPorId(rs.getInt("partida_id")).ifPresent(a::setPartida);
                lista.add(a);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    public List<ApostaResumo> buscarTodasComDetalhes() {
        List<ApostaResumo> lista = new ArrayList<>();
        String sql = """
            SELECT a.id, a.gols_mandante_apostado, a.gols_visitante_apostado, a.pontos_obtidos,
                   p.nome participante_nome,
                   m.nome mandante_nome, v.nome visitante_nome,
                   pa.gols_mandante, pa.gols_visitante, pa.finalizada
            FROM apostas a
            JOIN participantes p ON a.participante_id = p.id
            JOIN partidas pa ON a.partida_id = pa.id
            JOIN clubes m ON pa.clube_mandante_id = m.id
            JOIN clubes v ON pa.clube_visitante_id = v.id
            ORDER BY p.nome, pa.data_hora
            """;
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                ApostaResumo r = new ApostaResumo();
                r.participanteNome = rs.getString("participante_nome");
                r.partidaDesc = rs.getString("mandante_nome") + " x " + rs.getString("visitante_nome");
                r.apostaDesc = rs.getInt("gols_mandante_apostado") + " x " + rs.getInt("gols_visitante_apostado");
                boolean finalizada = rs.getInt("finalizada") == 1;
                r.resultadoReal = finalizada
                        ? rs.getInt("gols_mandante") + " x " + rs.getInt("gols_visitante")
                        : "—";
                r.pontos = finalizada ? String.valueOf(rs.getInt("pontos_obtidos")) : "—";
                lista.add(r);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    @Override
    public Optional<Aposta> buscarPorId(Integer id) {
        return Optional.empty();
    }

    @Override
    public List<Aposta> buscarTodos() {
        return List.of();
    }

    @Override
    public boolean deletar(Integer id) {
        try (PreparedStatement ps = con.prepareStatement("DELETE FROM apostas WHERE id = ?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Aposta atualizar(Aposta aposta) {
        return aposta;
    }

    public static class ApostaResumo {
        public String participanteNome;
        public String partidaDesc;
        public String apostaDesc;
        public String resultadoReal;
        public String pontos;
    }
}
