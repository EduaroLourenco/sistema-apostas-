package br.edu.sistema.interfaces;

public interface Visualizavel {
    String exibirClassificacao();
    String exibirDetalhes();
}
