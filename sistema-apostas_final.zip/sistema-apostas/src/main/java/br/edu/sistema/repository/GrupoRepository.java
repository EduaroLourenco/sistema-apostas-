package br.edu.sistema.repository;

import br.edu.sistema.db.ConexaoDB;
import br.edu.sistema.model.Grupo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class GrupoRepository implements Repository<Grupo, Integer> {

    private final Connection con;

    public GrupoRepository() {
        this.con = ConexaoDB.getInstancia().getConexao();
    }

    @Override
    public Grupo salvar(Grupo grupo) {
        String sql = "INSERT INTO grupos (nome) VALUES (?)";
        try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, grupo.getNome());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) grupo.setId(keys.getInt(1));
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar grupo: " + e.getMessage(), e);
        }
        return grupo;
    }

    @Override
    public Optional<Grupo> buscarPorId(Integer id) {
        try (PreparedStatement ps = con.prepareStatement("SELECT * FROM grupos WHERE id = ?")) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return Optional.of(mapear(rs));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return Optional.empty();
    }

    @Override
    public List<Grupo> buscarTodos() {
        List<Grupo> lista = new ArrayList<>();
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM grupos ORDER BY nome")) {
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    @Override
    public boolean deletar(Integer id) {
        try (PreparedStatement ps = con.prepareStatement("DELETE FROM grupos WHERE id = ?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Grupo atualizar(Grupo grupo) {
        try (PreparedStatement ps = con.prepareStatement("UPDATE grupos SET nome = ? WHERE id = ?")) {
            ps.setString(1, grupo.getNome());
            ps.setInt(2, grupo.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return grupo;
    }

    public static Grupo mapear(ResultSet rs) throws SQLException {
        Grupo g = new Grupo();
        g.setId(rs.getInt("id"));
        g.setNome(rs.getString("nome"));
        return g;
    }
}
