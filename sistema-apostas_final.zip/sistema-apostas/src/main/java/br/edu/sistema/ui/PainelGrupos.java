package br.edu.sistema.ui;

import br.edu.sistema.model.Grupo;
import br.edu.sistema.model.Participante;
import br.edu.sistema.service.SistemaApostas;
import br.edu.sistema.util.Tema;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PainelGrupos extends JPanel {

    private final SistemaApostas sistema = SistemaApostas.getInstancia();
    private JTextField txtNomeGrupo, txtNomeParticipante, txtEmailParticipante;
    private JComboBox<Grupo> cbGrupo;
    private JComboBox<Participante> cbParticipante;
    private DefaultTableModel tabelaGruposModel, tabelaParticipantesModel;

    public PainelGrupos() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Tema.FUNDO_PAINEL);
        setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        construir();
        atualizar();
    }

    private void construir() {
        JPanel superior = new JPanel(new GridLayout(1, 2, 12, 0));
        superior.setOpaque(false);

        JPanel formGrupo = Tema.painelForm("Grupos de Apostas");

        formGrupo.add(new JLabel("Nome do Grupo:"), Tema.gbc(0, 0));
        txtNomeGrupo = new JTextField(16);
        formGrupo.add(txtNomeGrupo, Tema.gbc(1, 0));

        JButton btnCriar = Tema.botaoPrimario("Criar Grupo");
        btnCriar.addActionListener(e -> criarGrupo());
        formGrupo.add(btnCriar, Tema.gbcSpan(0, 1, 2));

        formGrupo.add(new JSeparator(), Tema.gbcSpan(0, 2, 2));

        formGrupo.add(new JLabel("Grupo:"), Tema.gbc(0, 3));
        cbGrupo = new JComboBox<>();
        formGrupo.add(cbGrupo, Tema.gbc(1, 3));

        formGrupo.add(new JLabel("Participante:"), Tema.gbc(0, 4));
        cbParticipante = new JComboBox<>();
        formGrupo.add(cbParticipante, Tema.gbc(1, 4));

        JButton btnAdd = Tema.botaoSecundario("Adicionar ao Grupo");
        btnAdd.addActionListener(e -> adicionarAoGrupo());
        formGrupo.add(btnAdd, Tema.gbcSpan(0, 5, 2));

        superior.add(formGrupo);

        JPanel formParticipante = Tema.painelForm("Cadastrar Participante");

        formParticipante.add(new JLabel("Nome:"), Tema.gbc(0, 0));
        txtNomeParticipante = new JTextField(16);
        formParticipante.add(txtNomeParticipante, Tema.gbc(1, 0));

        formParticipante.add(new JLabel("E-mail:"), Tema.gbc(0, 1));
        txtEmailParticipante = new JTextField(16);
        formParticipante.add(txtEmailParticipante, Tema.gbc(1, 1));

        JButton btnCadastrar = Tema.botaoPrimario("Cadastrar Participante");
        btnCadastrar.addActionListener(e -> cadastrarParticipante());
        formParticipante.add(btnCadastrar, Tema.gbcSpan(0, 2, 2));

        superior.add(formParticipante);
        add(superior, BorderLayout.NORTH);

        JPanel painelTabelas = new JPanel(new GridLayout(1, 2, 12, 0));
        painelTabelas.setOpaque(false);

        tabelaGruposModel = new DefaultTableModel(new String[]{"ID", "Nome", "Participantes"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabelaGrupos = Tema.estilizarTabela(new JTable(tabelaGruposModel));
        JScrollPane scrollGrupos = new JScrollPane(tabelaGrupos);
        scrollGrupos.setBorder(Tema.bordaTitulada("Grupos"));
        painelTabelas.add(scrollGrupos);

        tabelaParticipantesModel = new DefaultTableModel(new String[]{"ID", "Nome", "E-mail", "Grupo", "Pontos"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabelaParticipantes = Tema.estilizarTabela(new JTable(tabelaParticipantesModel));
        JScrollPane scrollPart = new JScrollPane(tabelaParticipantes);
        scrollPart.setBorder(Tema.bordaTitulada("Participantes"));
        painelTabelas.add(scrollPart);

        add(painelTabelas, BorderLayout.CENTER);
    }

    private void criarGrupo() {
        String nome = txtNomeGrupo.getText().trim();
        if (nome.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o nome do grupo.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(this, sistema.cadastrarGrupo(nome), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        txtNomeGrupo.setText("");
        atualizar();
    }

    private void cadastrarParticipante() {
        String nome = txtNomeParticipante.getText().trim();
        String email = txtEmailParticipante.getText().trim();
        if (nome.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(this, sistema.cadastrarParticipante(nome, email), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        txtNomeParticipante.setText("");
        txtEmailParticipante.setText("");
        atualizar();
    }

    private void adicionarAoGrupo() {
        Grupo grupo = (Grupo) cbGrupo.getSelectedItem();
        Participante participante = (Participante) cbParticipante.getSelectedItem();
        JOptionPane.showMessageDialog(this, sistema.adicionarParticipanteAoGrupo(grupo, participante),
                "Resultado", JOptionPane.INFORMATION_MESSAGE);
        atualizar();
    }

    private void atualizar() {
        cbGrupo.removeAllItems();
        cbParticipante.removeAllItems();

        List<Grupo> grupos = sistema.getGrupos();
        tabelaGruposModel.setRowCount(0);
        for (Grupo g : grupos) {
            cbGrupo.addItem(g);
            int qtd = sistema.getParticipantesPorGrupo(g.getId()).size();
            tabelaGruposModel.addRow(new Object[]{g.getId(), g.getNome(), qtd + "/" + Grupo.MAX_PARTICIPANTES});
        }

        tabelaParticipantesModel.setRowCount(0);
        for (Participante p : sistema.getParticipantes()) {
            cbParticipante.addItem(p);
            String nomeGrupo = p.getGrupo() != null ? p.getGrupo().getNome() : "—";
            tabelaParticipantesModel.addRow(new Object[]{
                p.getId(), p.getNome(), p.getEmail(), nomeGrupo, p.getTotalPontos()
            });
        }
    }
}
