package br.edu.sistema.repository;

import java.util.List;
import java.util.Optional;

public interface Repository<T, ID> {
    T salvar(T entidade);
    Optional<T> buscarPorId(ID id);
    List<T> buscarTodos();
    boolean deletar(ID id);
    T atualizar(T entidade);
}
