package br.edu.sistema.util;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class Tema {

    public static final Color VERDE_ESCURO  = new Color(15, 70, 15);
    public static final Color VERDE_MEDIO   = new Color(27, 115, 27);
    public static final Color VERDE_CLARO   = new Color(56, 161, 56);
    public static final Color AZUL          = new Color(0, 90, 180);
    public static final Color VERMELHO      = new Color(180, 30, 30);
    public static final Color FUNDO_PAINEL  = new Color(248, 249, 250);
    public static final Color FUNDO_FORM    = Color.WHITE;
    public static final Color TEXTO_CLARO   = new Color(220, 240, 220);
    public static final Color BORDA         = new Color(200, 210, 200);

    public static final Font TITULO_FONTE   = new Font("SansSerif", Font.BOLD, 14);
    public static final Font LABEL_FONTE    = new Font("SansSerif", Font.PLAIN, 13);
    public static final Font MONO_FONTE     = new Font(Font.MONOSPACED, Font.PLAIN, 13);

    public static JButton botaoPrimario(String texto) {
        JButton btn = new JButton(texto);
        btn.setBackground(VERDE_MEDIO);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(180, 32));
        return btn;
    }

    public static JButton botaoSecundario(String texto) {
        JButton btn = new JButton(texto);
        btn.setBackground(AZUL);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(180, 32));
        return btn;
    }

    public static JButton botaoDanger(String texto) {
        JButton btn = new JButton(texto);
        btn.setBackground(VERMELHO);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(180, 32));
        return btn;
    }

    public static JPanel painelForm(String titulo) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(FUNDO_FORM);
        p.setBorder(bordaTitulada(titulo));
        return p;
    }

    public static Border bordaTitulada(String titulo) {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDA, 1, true),
                BorderFactory.createTitledBorder(
                        BorderFactory.createEmptyBorder(4, 8, 4, 8),
                        titulo,
                        javax.swing.border.TitledBorder.LEFT,
                        javax.swing.border.TitledBorder.TOP,
                        TITULO_FONTE,
                        VERDE_ESCURO
                )
        );
    }

    public static JTable estilizarTabela(JTable t) {
        t.setRowHeight(26);
        t.setFont(LABEL_FONTE);
        t.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));
        t.getTableHeader().setBackground(VERDE_ESCURO);
        t.getTableHeader().setForeground(Color.WHITE);
        t.setGridColor(new Color(220, 228, 220));
        t.setSelectionBackground(new Color(200, 230, 200));
        t.setSelectionForeground(Color.BLACK);
        t.getTableHeader().setReorderingAllowed(false);
        t.setFillsViewportHeight(true);
        return t;
    }

    public static GridBagConstraints gbc(int x, int y) {
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = x; g.gridy = y;
        g.insets = new Insets(5, 8, 5, 8);
        g.fill = GridBagConstraints.HORIZONTAL;
        g.anchor = GridBagConstraints.WEST;
        return g;
    }

    public static GridBagConstraints gbcSpan(int x, int y, int largura) {
        GridBagConstraints g = gbc(x, y);
        g.gridwidth = largura;
        g.anchor = GridBagConstraints.CENTER;
        return g;
    }
}
