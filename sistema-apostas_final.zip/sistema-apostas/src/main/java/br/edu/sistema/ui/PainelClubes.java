package br.edu.sistema.ui;

import br.edu.sistema.model.Clube;
import br.edu.sistema.service.SistemaApostas;
import br.edu.sistema.util.Tema;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class PainelClubes extends JPanel {

    private final SistemaApostas sistema = SistemaApostas.getInstancia();
    private JTextField txtNome, txtCidade, txtEstadio;
    private DefaultTableModel tableModel;

    public PainelClubes() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Tema.FUNDO_PAINEL);
        setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        construir();
        atualizar();
    }

    private void construir() {
        JPanel form = Tema.painelForm("Cadastrar Clube");

        form.add(new JLabel("Nome do Clube:"), Tema.gbc(0, 0));
        txtNome = new JTextField(22);
        form.add(txtNome, Tema.gbc(1, 0));

        form.add(new JLabel("Cidade:"), Tema.gbc(0, 1));
        txtCidade = new JTextField(22);
        form.add(txtCidade, Tema.gbc(1, 1));

        form.add(new JLabel("Estádio:"), Tema.gbc(0, 2));
        txtEstadio = new JTextField(22);
        form.add(txtEstadio, Tema.gbc(1, 2));

        JButton btn = Tema.botaoPrimario("Cadastrar Clube");
        btn.addActionListener(e -> cadastrar());
        form.add(btn, Tema.gbcSpan(0, 3, 2));

        add(form, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new String[]{"ID", "Nome", "Cidade", "Estádio"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabela = Tema.estilizarTabela(new JTable(tableModel));
        tabela.getColumnModel().getColumn(0).setPreferredWidth(45);

        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(Tema.bordaTitulada("Clubes Cadastrados"));
        scroll.setBackground(Tema.FUNDO_PAINEL);
        add(scroll, BorderLayout.CENTER);
    }

    private void cadastrar() {
        String nome = txtNome.getText().trim();
        String cidade = txtCidade.getText().trim();
        String estadio = txtEstadio.getText().trim();

        if (nome.isEmpty() || cidade.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nome e cidade são obrigatórios.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(this, sistema.cadastrarClube(nome, cidade, estadio),
                "Resultado", JOptionPane.INFORMATION_MESSAGE);
        txtNome.setText(""); txtCidade.setText(""); txtEstadio.setText("");
        atualizar();
    }

    private void atualizar() {
        tableModel.setRowCount(0);
        for (Clube c : sistema.getClubes()) {
            tableModel.addRow(new Object[]{c.getId(), c.getNome(), c.getCidade(), c.getEstadio()});
        }
    }
}
