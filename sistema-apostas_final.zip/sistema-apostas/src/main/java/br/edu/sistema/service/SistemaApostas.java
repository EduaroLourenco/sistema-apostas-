package br.edu.sistema.service;

import br.edu.sistema.model.*;
import br.edu.sistema.repository.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public class SistemaApostas {

    private static SistemaApostas instancia;

    private final ClubeRepository clubeRepo;
    private final CampeonatoRepository campeonatoRepo;
    private final PartidaRepository partidaRepo;
    private final GrupoRepository grupoRepo;
    private final ParticipanteRepository participanteRepo;
    private final ApostaRepository apostaRepo;
    private final EventoRepository eventoRepo;

    private final Administrador administrador;

    private SistemaApostas() {
        clubeRepo = new ClubeRepository();
        campeonatoRepo = new CampeonatoRepository();
        partidaRepo = new PartidaRepository();
        grupoRepo = new GrupoRepository();
        participanteRepo = new ParticipanteRepository();
        apostaRepo = new ApostaRepository();
        eventoRepo = new EventoRepository();

        administrador = new Administrador("Administrador", "admin@sistema.com", "admin123");

        if (clubeRepo.buscarTodos().isEmpty()) {
            carregarDadosIniciais();
        }
    }

    public static SistemaApostas getInstancia() {
        if (instancia == null) {
            instancia = new SistemaApostas();
        }
        return instancia;
    }

    private void carregarDadosIniciais() {
        Clube c1 = clubeRepo.salvar(new Clube("Flamengo", "Rio de Janeiro", "Maracanã"));
        Clube c2 = clubeRepo.salvar(new Clube("Palmeiras", "São Paulo", "Allianz Parque"));
        Clube c3 = clubeRepo.salvar(new Clube("Grêmio", "Porto Alegre", "Arena do Grêmio"));
        Clube c4 = clubeRepo.salvar(new Clube("Atlético-MG", "Belo Horizonte", "Arena MRV"));

        Campeonato camp = campeonatoRepo.salvar(new Campeonato("Brasileirão Série A", "2026"));
        campeonatoRepo.vincularClube(camp.getId(), c1.getId());
        campeonatoRepo.vincularClube(camp.getId(), c2.getId());
        campeonatoRepo.vincularClube(camp.getId(), c3.getId());
        campeonatoRepo.vincularClube(camp.getId(), c4.getId());

        camp.adicionarClube(c1);
        camp.adicionarClube(c2);
        camp.adicionarClube(c3);
        camp.adicionarClube(c4);

        Partida p1 = new Partida(c1, c2, LocalDateTime.now().plusDays(5), camp);
        Partida p2 = new Partida(c3, c4, LocalDateTime.now().plusDays(6), camp);
        partidaRepo.salvar(p1);
        partidaRepo.salvar(p2);

        eventoRepo.registrar("SISTEMA", "Dados iniciais carregados.");
    }

    public String cadastrarClube(String nome, String cidade, String estadio) {
        if (nome == null || nome.trim().isEmpty()) return "Nome do clube inválido.";
        Clube clube = clubeRepo.salvar(new Clube(nome.trim(), cidade.trim(), estadio.trim()));
        eventoRepo.registrar("CLUBE", "Clube '" + nome + "' cadastrado (ID " + clube.getId() + ").");
        return "Clube '" + nome + "' cadastrado com sucesso!";
    }

    public String cadastrarCampeonato(String nome, String edicao) {
        if (nome == null || nome.trim().isEmpty()) return "Nome do campeonato inválido.";
        Campeonato camp = campeonatoRepo.salvar(new Campeonato(nome.trim(), edicao.trim()));
        eventoRepo.registrar("CAMPEONATO", "Campeonato '" + nome + "' criado.");
        return "Campeonato '" + nome + "' cadastrado com sucesso!";
    }

    public String adicionarClubeAoCampeonato(Campeonato campeonato, Clube clube) {
        if (campeonato == null || clube == null) return "Seleção inválida.";
        List<Clube> atuais = campeonatoRepo.buscarClubesDoCampeonato(campeonato.getId());
        if (atuais.stream().anyMatch(c -> c.getId() == clube.getId())) {
            return "Clube já pertence a esse campeonato.";
        }
        if (atuais.size() >= Campeonato.MAX_CLUBES) {
            return "Limite de clubes atingido para este campeonato.";
        }
        campeonatoRepo.vincularClube(campeonato.getId(), clube.getId());
        eventoRepo.registrar("CAMPEONATO", "Clube '" + clube.getNome() + "' adicionado a '" + campeonato.getNome() + "'.");
        return "Clube '" + clube.getNome() + "' adicionado ao campeonato!";
    }

    public String cadastrarPartida(Campeonato campeonato, Clube mandante, Clube visitante, LocalDateTime dataHora) {
        if (campeonato == null || mandante == null || visitante == null || dataHora == null) {
            return "Preencha todos os campos.";
        }
        if (mandante.getId() == visitante.getId()) {
            return "Mandante e visitante não podem ser o mesmo clube.";
        }
        List<Clube> clubesDoCamp = campeonatoRepo.buscarClubesDoCampeonato(campeonato.getId());
        boolean mandanteOk = clubesDoCamp.stream().anyMatch(c -> c.getId() == mandante.getId());
        boolean visitanteOk = clubesDoCamp.stream().anyMatch(c -> c.getId() == visitante.getId());
        if (!mandanteOk || !visitanteOk) {
            return "Os clubes devem pertencer ao campeonato selecionado.";
        }
        Partida p = new Partida(mandante, visitante, dataHora, campeonato);
        partidaRepo.salvar(p);
        eventoRepo.registrar("PARTIDA", mandante.getNome() + " x " + visitante.getNome() + " agendada.");
        return "Partida cadastrada com sucesso!";
    }

    public String cadastrarGrupo(String nome) {
        if (nome == null || nome.trim().isEmpty()) return "Nome do grupo inválido.";
        grupoRepo.salvar(new Grupo(nome.trim()));
        eventoRepo.registrar("GRUPO", "Grupo '" + nome + "' criado.");
        return "Grupo '" + nome + "' criado com sucesso!";
    }

    public String cadastrarParticipante(String nome, String email) {
        if (nome == null || nome.trim().isEmpty() || email == null || email.trim().isEmpty()) {
            return "Preencha todos os campos.";
        }
        participanteRepo.salvar(new Participante(nome.trim(), email.trim()));
        eventoRepo.registrar("PARTICIPANTE", "Participante '" + nome + "' cadastrado.");
        return "Participante '" + nome + "' cadastrado com sucesso!";
    }

    public String adicionarParticipanteAoGrupo(Grupo grupo, Participante participante) {
        if (grupo == null || participante == null) return "Seleção inválida.";
        List<Participante> membros = participanteRepo.buscarPorGrupo(grupo.getId());
        if (membros.stream().anyMatch(p -> p.getId() == participante.getId())) {
            return "Participante já pertence a esse grupo.";
        }
        if (membros.size() >= Grupo.MAX_PARTICIPANTES) {
            return "Limite de participantes do grupo atingido.";
        }
        participante.setGrupo(grupo);
        participanteRepo.atualizar(participante);
        eventoRepo.registrar("GRUPO", participante.getNome() + " adicionado ao grupo '" + grupo.getNome() + "'.");
        return "Participante adicionado ao grupo '" + grupo.getNome() + "' com sucesso!";
    }

    public String registrarAposta(Participante participante, Partida partida,
                                   int golsMandante, int golsVisitante) {
        if (participante == null || partida == null) return "Seleção inválida.";
        if (!partida.isApostaPermitida()) {
            return "Prazo encerrado! Apostas só até 20 minutos antes da partida.";
        }
        List<Aposta> existentes = apostaRepo.buscarPorParticipante(participante.getId(), partidaRepo, participanteRepo);
        boolean jaApostou = existentes.stream()
                .anyMatch(a -> a.getPartida() != null && a.getPartida().getId() == partida.getId());
        if (jaApostou) {
            return "Você já apostou nessa partida.";
        }
        Aposta aposta = new Aposta(participante, partida, golsMandante, golsVisitante);
        apostaRepo.salvar(aposta);
        eventoRepo.registrar("APOSTA", participante.getNome() + " apostou "
                + golsMandante + "x" + golsVisitante + " em "
                + partida.getClubeMandante().getNome() + " x " + partida.getClubeVisitante().getNome());
        return "Aposta registrada: " + golsMandante + " x " + golsVisitante + " ✓";
    }

    public String registrarResultado(Partida partida, int golsMandante, int golsVisitante, String senha) {
        if (!administrador.autenticar(senha)) return "Senha incorreta. Acesso negado.";
        if (partida == null) return "Partida inválida.";
        if (partida.isFinalizada()) return "Essa partida já possui resultado registrado.";

        partida.registrarResultado(golsMandante, golsVisitante);
        partidaRepo.atualizar(partida);

        List<Aposta> apostas = apostaRepo.buscarPorPartida(partida.getId(), partidaRepo, participanteRepo);
        for (Aposta a : apostas) {
            Participante p = a.getParticipante();
            if (p == null) continue;
            Optional<Participante> pOpt = participanteRepo.buscarPorId(p.getId());
            if (pOpt.isEmpty()) continue;
            Participante participante = pOpt.get();

            a.setPartida(partida);
            int pontos = participante.calcularPontos(a, partida);
            a.setPontosObtidos(pontos);
            apostaRepo.atualizarPontos(a.getId(), pontos);
            participante.adicionarPontos(pontos);
            participanteRepo.atualizar(participante);
        }

        String resultado = partida.getClubeMandante().getNome() + " " + golsMandante
                + " x " + golsVisitante + " " + partida.getClubeVisitante().getNome();
        eventoRepo.registrar("RESULTADO", "Resultado registrado: " + resultado);
        return "Resultado registrado: " + golsMandante + " x " + golsVisitante + ". Pontuações atualizadas!";
    }

    public List<Clube> getClubes() { return clubeRepo.buscarTodos(); }
    public List<Campeonato> getCampeonatos() { return campeonatoRepo.buscarTodos(); }
    public List<Partida> getTodasPartidas() { return partidaRepo.buscarTodos(); }
    public List<Grupo> getGrupos() { return grupoRepo.buscarTodos(); }
    public List<Participante> getParticipantes() { return participanteRepo.buscarTodos(); }
    public List<Participante> getParticipantesPorGrupo(int grupoId) { return participanteRepo.buscarPorGrupo(grupoId); }
    public List<Aposta> getApostasDo(Participante p) { return apostaRepo.buscarPorParticipante(p.getId(), partidaRepo, participanteRepo); }
    public List<ApostaRepository.ApostaResumo> getTodasApostasResumo() { return apostaRepo.buscarTodasComDetalhes(); }
    public List<String[]> getHistoricoRecente(int n) { return eventoRepo.buscarRecentes(n); }
    public List<Clube> getClubesDoCampeonato(int campeonatoId) { return campeonatoRepo.buscarClubesDoCampeonato(campeonatoId); }
    public Administrador getAdministrador() { return administrador; }
}
