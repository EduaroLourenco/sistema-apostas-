package br.edu.sistema.ui;

import br.edu.sistema.model.Partida;
import br.edu.sistema.model.Participante;
import br.edu.sistema.repository.ApostaRepository;
import br.edu.sistema.service.SistemaApostas;
import br.edu.sistema.util.Tema;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PainelApostas extends JPanel {

    private final SistemaApostas sistema = SistemaApostas.getInstancia();
    private JComboBox<Participante> cbParticipante;
    private JComboBox<Partida> cbPartida;
    private JSpinner spMandante, spVisitante;
    private DefaultTableModel tableModel;

    public PainelApostas() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Tema.FUNDO_PAINEL);
        setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        construir();
        atualizar();
    }

    private void construir() {
        JPanel form = Tema.painelForm("Registrar Aposta");

        form.add(new JLabel("Participante:"), Tema.gbc(0, 0));
        cbParticipante = new JComboBox<>();
        form.add(cbParticipante, Tema.gbc(1, 0));

        form.add(new JLabel("Partida:"), Tema.gbc(0, 1));
        cbPartida = new JComboBox<>();
        form.add(cbPartida, Tema.gbc(1, 1));

        form.add(new JLabel("Gols Mandante:"), Tema.gbc(0, 2));
        spMandante = new JSpinner(new SpinnerNumberModel(0, 0, 20, 1));
        form.add(spMandante, Tema.gbc(1, 2));

        form.add(new JLabel("Gols Visitante:"), Tema.gbc(0, 3));
        spVisitante = new JSpinner(new SpinnerNumberModel(0, 0, 20, 1));
        form.add(spVisitante, Tema.gbc(1, 3));

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        botoes.setOpaque(false);
        JButton btnApostar = Tema.botaoPrimario("Registrar Aposta");
        btnApostar.addActionListener(e -> registrar());
        JButton btnAtualizar = Tema.botaoSecundario("Atualizar Listas");
        btnAtualizar.addActionListener(e -> atualizar());
        botoes.add(btnApostar);
        botoes.add(btnAtualizar);

        GridBagConstraints gbc = Tema.gbcSpan(0, 4, 2);
        gbc.fill = GridBagConstraints.NONE;
        form.add(botoes, gbc);

        add(form, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(
                new String[]{"Participante", "Partida", "Aposta", "Resultado Real", "Pontos"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabela = Tema.estilizarTabela(new JTable(tableModel));
        tabela.getColumnModel().getColumn(4).setPreferredWidth(60);

        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(Tema.bordaTitulada("Apostas Registradas"));
        add(scroll, BorderLayout.CENTER);
    }

    private void registrar() {
        Participante p = (Participante) cbParticipante.getSelectedItem();
        Partida partida = (Partida) cbPartida.getSelectedItem();

        if (p == null || partida == null) {
            JOptionPane.showMessageDialog(this, "Selecione participante e partida.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int gM = (Integer) spMandante.getValue();
        int gV = (Integer) spVisitante.getValue();
        String msg = sistema.registrarAposta(p, partida, gM, gV);
        JOptionPane.showMessageDialog(this, msg, "Resultado", JOptionPane.INFORMATION_MESSAGE);
        atualizar();
    }

    private void atualizar() {
        cbParticipante.removeAllItems();
        for (Participante p : sistema.getParticipantes()) cbParticipante.addItem(p);

        cbPartida.removeAllItems();
        for (Partida p : sistema.getTodasPartidas()) {
            if (!p.isFinalizada()) cbPartida.addItem(p);
        }

        tableModel.setRowCount(0);
        List<ApostaRepository.ApostaResumo> resumos = sistema.getTodasApostasResumo();
        for (ApostaRepository.ApostaResumo r : resumos) {
            tableModel.addRow(new Object[]{
                r.participanteNome, r.partidaDesc, r.apostaDesc, r.resultadoReal, r.pontos
            });
        }
    }
}
