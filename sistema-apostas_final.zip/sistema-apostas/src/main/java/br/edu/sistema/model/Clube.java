package br.edu.sistema.model;

public class Clube extends EntidadeBase {

    private String cidade;
    private String estadio;

    public Clube() { super(); }

    public Clube(String nome, String cidade, String estadio) {
        super(nome);
        this.cidade = cidade;
        this.estadio = estadio;
    }

    public String getCidade() { return cidade; }
    public void setCidade(String cidade) { this.cidade = cidade; }
    public String getEstadio() { return estadio; }
    public void setEstadio(String estadio) { this.estadio = estadio; }

    @Override
    public boolean cadastrar() {
        return super.cadastrar() && cidade != null && !cidade.trim().isEmpty();
    }

    @Override
    public String getInfo() {
        return super.getInfo() + " | Cidade: " + cidade + " | Estádio: " + estadio;
    }

    @Override
    public String getTipoEntidade() { return "Clube"; }
}
