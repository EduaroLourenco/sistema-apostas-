package br.edu.sistema.ui;

import br.edu.sistema.util.Tema;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    public MainFrame() {
        setTitle("Sistema de Apostas — Campeonato de Futebol");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(980, 680);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(860, 580));
        getContentPane().setBackground(Tema.FUNDO_PAINEL);
        construir();
    }

    private void construir() {
        setLayout(new BorderLayout());

        JPanel topo = new JPanel(new BorderLayout());
        topo.setBackground(Tema.VERDE_ESCURO);
        topo.setBorder(BorderFactory.createEmptyBorder(14, 20, 14, 20));

        JLabel titulo = new JLabel("⚽  Sistema de Apostas — Campeonato de Futebol");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 19));
        titulo.setForeground(Color.WHITE);

        JLabel info = new JLabel("Senha admin: admin123  |  BD: apostas.db");
        info.setFont(new Font("SansSerif", Font.PLAIN, 11));
        info.setForeground(Tema.TEXTO_CLARO);

        topo.add(titulo, BorderLayout.WEST);
        topo.add(info, BorderLayout.EAST);
        add(topo, BorderLayout.NORTH);

        JTabbedPane abas = new JTabbedPane(JTabbedPane.TOP);
        abas.setFont(new Font("SansSerif", Font.PLAIN, 13));
        abas.setBackground(Tema.FUNDO_PAINEL);

        abas.addTab("⚽  Clubes",       new PainelClubes());
        abas.addTab("🏆  Campeonatos",  new PainelCampeonatos());
        abas.addTab("📅  Partidas",     new PainelPartidas());
        abas.addTab("👥  Grupos",       new PainelGrupos());
        abas.addTab("🎯  Apostas",      new PainelApostas());
        abas.addTab("📊  Resultados",   new PainelResultados());
        abas.addTab("📜  Histórico",    new PainelHistorico());

        add(abas, BorderLayout.CENTER);

        JPanel rodape = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 4));
        rodape.setBackground(new Color(235, 238, 235));
        rodape.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, Tema.BORDA));
        JLabel lblRodape = new JLabel("LPOO 2026  •  SQLite  •  Padrão Repository");
        lblRodape.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblRodape.setForeground(Color.GRAY);
        rodape.add(lblRodape);
        add(rodape, BorderLayout.SOUTH);
    }
}
