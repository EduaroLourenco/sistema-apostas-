package br.edu.sistema.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Partida {

    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private int id;
    private Clube clubeMandante;
    private Clube clubeVisitante;
    private LocalDateTime dataHora;
    private int golsMandante = -1;
    private int golsVisitante = -1;
    private boolean finalizada = false;
    private Campeonato campeonato;

    public Partida() {}

    public Partida(Clube mandante, Clube visitante, LocalDateTime dataHora, Campeonato campeonato) {
        this.clubeMandante = mandante;
        this.clubeVisitante = visitante;
        this.dataHora = dataHora;
        this.campeonato = campeonato;
    }

    public void registrarResultado(int golsMandante, int golsVisitante) {
        this.golsMandante = golsMandante;
        this.golsVisitante = golsVisitante;
        this.finalizada = true;
    }

    public String getResultado() {
        if (!finalizada) return "Não finalizada";
        if (golsMandante > golsVisitante) return clubeMandante.getNome();
        if (golsVisitante > golsMandante) return clubeVisitante.getNome();
        return "Empate";
    }

    public boolean isApostaPermitida() {
        return LocalDateTime.now().isBefore(dataHora.minusMinutes(20));
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public Clube getClubeMandante() { return clubeMandante; }
    public void setClubeMandante(Clube clubeMandante) { this.clubeMandante = clubeMandante; }
    public Clube getClubeVisitante() { return clubeVisitante; }
    public void setClubeVisitante(Clube clubeVisitante) { this.clubeVisitante = clubeVisitante; }
    public LocalDateTime getDataHora() { return dataHora; }
    public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }
    public int getGolsMandante() { return golsMandante; }
    public void setGolsMandante(int golsMandante) { this.golsMandante = golsMandante; }
    public int getGolsVisitante() { return golsVisitante; }
    public void setGolsVisitante(int golsVisitante) { this.golsVisitante = golsVisitante; }
    public boolean isFinalizada() { return finalizada; }
    public void setFinalizada(boolean finalizada) { this.finalizada = finalizada; }
    public Campeonato getCampeonato() { return campeonato; }
    public void setCampeonato(Campeonato campeonato) { this.campeonato = campeonato; }

    @Override
    public String toString() {
        return clubeMandante.getNome() + " x " + clubeVisitante.getNome()
                + " — " + dataHora.format(FORMATTER);
    }
}
