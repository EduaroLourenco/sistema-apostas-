package br.edu.sistema.repository;

import br.edu.sistema.db.ConexaoDB;
import br.edu.sistema.model.Campeonato;
import br.edu.sistema.model.Clube;
import br.edu.sistema.model.Partida;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public class PartidaRepository implements Repository<Partida, Integer> {

    private final Connection con;

    public PartidaRepository() {
        this.con = ConexaoDB.getInstancia().getConexao();
    }

    @Override
    public Partida salvar(Partida p) {
        String sql = """
            INSERT INTO partidas (campeonato_id, clube_mandante_id, clube_visitante_id,
                data_hora, gols_mandante, gols_visitante, finalizada)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """;
        try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, p.getCampeonato().getId());
            ps.setInt(2, p.getClubeMandante().getId());
            ps.setInt(3, p.getClubeVisitante().getId());
            ps.setString(4, p.getDataHora().toString());
            ps.setInt(5, p.getGolsMandante());
            ps.setInt(6, p.getGolsVisitante());
            ps.setInt(7, p.isFinalizada() ? 1 : 0);
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) p.setId(keys.getInt(1));
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar partida: " + e.getMessage(), e);
        }
        return p;
    }

    @Override
    public Optional<Partida> buscarPorId(Integer id) {
        String sql = buildSelectBase() + " WHERE p.id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return Optional.of(mapear(rs));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return Optional.empty();
    }

    @Override
    public List<Partida> buscarTodos() {
        List<Partida> lista = new ArrayList<>();
        String sql = buildSelectBase() + " ORDER BY p.data_hora";
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    public List<Partida> buscarPorCampeonato(int campeonatoId) {
        List<Partida> lista = new ArrayList<>();
        String sql = buildSelectBase() + " WHERE p.campeonato_id = ? ORDER BY p.data_hora";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, campeonatoId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    @Override
    public boolean deletar(Integer id) {
        try (PreparedStatement ps = con.prepareStatement("DELETE FROM partidas WHERE id = ?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Partida atualizar(Partida p) {
        String sql = """
            UPDATE partidas SET gols_mandante = ?, gols_visitante = ?, finalizada = ?
            WHERE id = ?
            """;
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, p.getGolsMandante());
            ps.setInt(2, p.getGolsVisitante());
            ps.setInt(3, p.isFinalizada() ? 1 : 0);
            ps.setInt(4, p.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return p;
    }

    private String buildSelectBase() {
        return """
            SELECT p.*,
                   m.id m_id, m.nome m_nome, m.cidade m_cidade, m.estadio m_estadio,
                   v.id v_id, v.nome v_nome, v.cidade v_cidade, v.estadio v_estadio,
                   c.id c_id, c.nome c_nome, c.edicao c_edicao
            FROM partidas p
            JOIN clubes m ON p.clube_mandante_id = m.id
            JOIN clubes v ON p.clube_visitante_id = v.id
            JOIN campeonatos c ON p.campeonato_id = c.id
            """;
    }

    public static Partida mapear(ResultSet rs) throws SQLException {
        Clube mandante = new Clube();
        mandante.setId(rs.getInt("m_id"));
        mandante.setNome(rs.getString("m_nome"));
        mandante.setCidade(rs.getString("m_cidade"));
        mandante.setEstadio(rs.getString("m_estadio"));

        Clube visitante = new Clube();
        visitante.setId(rs.getInt("v_id"));
        visitante.setNome(rs.getString("v_nome"));
        visitante.setCidade(rs.getString("v_cidade"));
        visitante.setEstadio(rs.getString("v_estadio"));

        Campeonato camp = new Campeonato();
        camp.setId(rs.getInt("c_id"));
        camp.setNome(rs.getString("c_nome"));
        camp.setEdicao(rs.getString("c_edicao"));

        Partida p = new Partida();
        p.setId(rs.getInt("id"));
        p.setClubeMandante(mandante);
        p.setClubeVisitante(visitante);
        p.setCampeonato(camp);
        p.setDataHora(LocalDateTime.parse(rs.getString("data_hora")));
        p.setGolsMandante(rs.getInt("gols_mandante"));
        p.setGolsVisitante(rs.getInt("gols_visitante"));
        p.setFinalizada(rs.getInt("finalizada") == 1);
        return p;
    }
}
