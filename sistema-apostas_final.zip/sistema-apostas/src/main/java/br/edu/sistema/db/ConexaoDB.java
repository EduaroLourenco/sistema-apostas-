package br.edu.sistema.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConexaoDB {

    private static final String URL = "jdbc:h2:./apostas;DB_CLOSE_DELAY=-1;AUTO_SERVER=FALSE";
    private static ConexaoDB instancia;
    private Connection conexao;

    private ConexaoDB() {
        conectar();
        criarTabelas();
    }

    public static ConexaoDB getInstancia() {
        if (instancia == null) {
            instancia = new ConexaoDB();
        }
        return instancia;
    }

    private void conectar() {
        try {
            Class.forName("org.h2.Driver");
            conexao = DriverManager.getConnection(URL, "sa", "");
        } catch (Exception e) {
            throw new RuntimeException("Falha ao conectar ao banco de dados: " + e.getMessage(), e);
        }
    }

    public Connection getConexao() {
        try {
            if (conexao == null || conexao.isClosed()) conectar();
        } catch (SQLException e) {
            conectar();
        }
        return conexao;
    }

    private void criarTabelas() {
        String[] sqls = {
            """
            CREATE TABLE IF NOT EXISTS clubes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nome VARCHAR(100) NOT NULL,
                cidade VARCHAR(100) NOT NULL,
                estadio VARCHAR(100)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS campeonatos (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nome VARCHAR(100) NOT NULL,
                edicao VARCHAR(50)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS campeonato_clubes (
                campeonato_id INT,
                clube_id INT,
                PRIMARY KEY (campeonato_id, clube_id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS partidas (
                id INT AUTO_INCREMENT PRIMARY KEY,
                campeonato_id INT NOT NULL,
                clube_mandante_id INT NOT NULL,
                clube_visitante_id INT NOT NULL,
                data_hora VARCHAR(30) NOT NULL,
                gols_mandante INT DEFAULT -1,
                gols_visitante INT DEFAULT -1,
                finalizada INT DEFAULT 0
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS grupos (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nome VARCHAR(100) NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS participantes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nome VARCHAR(100) NOT NULL,
                email VARCHAR(150) NOT NULL,
                total_pontos INT DEFAULT 0,
                grupo_id INT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS apostas (
                id INT AUTO_INCREMENT PRIMARY KEY,
                participante_id INT NOT NULL,
                partida_id INT NOT NULL,
                gols_mandante_apostado INT NOT NULL,
                gols_visitante_apostado INT NOT NULL,
                pontos_obtidos INT DEFAULT 0,
                UNIQUE(participante_id, partida_id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS historico_eventos (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tipo VARCHAR(50) NOT NULL,
                descricao VARCHAR(500) NOT NULL,
                data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        };

        try (Statement st = conexao.createStatement()) {
            for (String sql : sqls) st.execute(sql);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao criar tabelas: " + e.getMessage(), e);
        }
    }

    public void fechar() {
        try {
            if (conexao != null && !conexao.isClosed()) conexao.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
