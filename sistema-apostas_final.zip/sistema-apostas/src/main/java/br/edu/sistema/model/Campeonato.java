package br.edu.sistema.model;

import java.util.ArrayList;
import java.util.List;

public class Campeonato extends EntidadeBase {

    public static final int MAX_CLUBES = 20;

    private String edicao;
    private List<Clube> clubes = new ArrayList<>();
    private List<Partida> partidas = new ArrayList<>();

    public Campeonato() { super(); }

    public Campeonato(String nome, String edicao) {
        super(nome);
        this.edicao = edicao;
    }

    public boolean adicionarClube(Clube clube) {
        if (clubes.size() >= MAX_CLUBES) return false;
        if (clubes.stream().anyMatch(c -> c.getId() == clube.getId())) return false;
        return clubes.add(clube);
    }

    public boolean adicionarPartida(Partida partida) {
        return partidas.add(partida);
    }

    public List<Clube> getClubes() { return clubes; }
    public List<Partida> getPartidas() { return partidas; }
    public String getEdicao() { return edicao; }
    public void setEdicao(String edicao) { this.edicao = edicao; }

    @Override
    public String getInfo() {
        return super.getInfo() + " | Edição: " + edicao
                + " | Clubes: " + clubes.size() + "/" + MAX_CLUBES;
    }

    @Override
    public String getTipoEntidade() { return "Campeonato"; }
}
